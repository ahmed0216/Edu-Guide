<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TasksController;
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('/signUp', [AuthController::class, 'signUp']);
Route::post('/logIn', [AuthController::class, 'logIn']);
Route::post('/logOut', [AuthController::class, 'logOut']);
Route::post('/resetPass', [AuthController::class, 'resetPass']);
//Route::put('/userUpdate', [AuthController::class, 'userUpdate']);
Route::post('/userUpdate/{id}', [AuthController::class, 'updateUser']);
Route::delete('/deleteUser', [AuthController::class,'deleteUser']);
Route::post('/updateImage/{id}', [AuthController::class, 'updateImage']);


Route::post('/addTask', [TasksController::class, 'store']);
Route::put('/endTask/{taskId}', [TasksController::class, 'toggleStatus']);
Route::delete('/deleteTask/{taskId}', [TasksController::class, 'destroy']);
Route::get('/tasks/{user_id}', [TasksController::class, 'index']);
//Route::get('/tasks/{taskId}', [TasksController::class, 'getTasks']);
Route::get('/showTask/{taskId}', [TasksController::class, 'show']);
Route::get('/completedTasks/{taskId}', [TasksController::class, 'getCompletedTasks']);
Route::put('/tasks/{taskId}/updateDescription', [TasksController::class, 'updateDescription']);