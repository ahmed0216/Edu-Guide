-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2024 at 09:06 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2014_10_12_000000_create_users_table', 1),
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_08_19_000000_create_failed_jobs_table', 1),
(13, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(14, '2024_03_09_072219_create_tasks_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(13, 'App\\Models\\User', 1, 'عبد الرازق', '5f002c64d258c80b04d77b09286cebf5964c979c71b01e6b1e53af846bcb8e57', '[\"*\"]', NULL, '2024-03-09 06:15:36', '2024-03-09 06:15:36'),
(14, 'App\\Models\\User', 1, 'عبد الرازق', '69fc04987222cd0b3f670e33e272a42f8a88d2dce8968fb1fb0cea945bfdec7a', '[\"*\"]', NULL, '2024-03-09 06:18:04', '2024-03-09 06:18:04'),
(15, 'App\\Models\\User', 1, 'عبد الرازق', '2c20c5df2ddf30d7921bfd33b6ed7c6d5a55f13e75b1a416eef925899cbc262c', '[\"*\"]', NULL, '2024-03-09 06:20:41', '2024-03-09 06:20:41'),
(16, 'App\\Models\\User', 1, 'عبد الرازق', '06ee65424c2f4d3299b6db62a613621190bf21136e6d9ce194e58d5ca0b8c5bd', '[\"*\"]', NULL, '2024-03-09 06:20:41', '2024-03-09 06:20:41'),
(17, 'App\\Models\\User', 1, 'عبد الرازق', 'd6a4943ffa474e92217fd1e895fe4216b707d91f2b0137f33384ac41d93b627a', '[\"*\"]', NULL, '2024-03-09 06:21:49', '2024-03-09 06:21:49'),
(18, 'App\\Models\\User', 1, 'عبد الرازق', '2cede24a1212464894aad4fbff86d4f8a7e1bad304319d1c0f7d441f16fdaf63', '[\"*\"]', NULL, '2024-03-09 06:21:49', '2024-03-09 06:21:49'),
(21, 'App\\Models\\User', 1, 'عبد الرازق', '948be1560828ba4f9fa1d20ea5994e6e28330f4969c6a92a25d0f70be61c1cc6', '[\"*\"]', NULL, '2024-03-09 06:23:27', '2024-03-09 06:23:27'),
(22, 'App\\Models\\User', 1, 'عبد الرازق', 'a1c31b8940bd851809e0b4d1ccf7e226fdff9f62a8cebd2f97e055ffabdbce3a', '[\"*\"]', NULL, '2024-03-09 06:23:27', '2024-03-09 06:23:27'),
(23, 'App\\Models\\User', 1, 'عبد الرازق', '4e71980e79964bcda4202b392dc2a83967e0331cb24105069e0a722da8dfc3d0', '[\"*\"]', NULL, '2024-03-09 07:40:51', '2024-03-09 07:40:51'),
(24, 'App\\Models\\User', 1, 'عبد الرازق', '9b6170b2531271f4655966a31d20777b30be6999a49b8287a3d557e7ead597ba', '[\"*\"]', NULL, '2024-03-09 07:40:51', '2024-03-09 07:40:51'),
(25, 'App\\Models\\User', 1, 'عبد الرازق', '8cca46b20e0ab223dd9a616d42384e12ebb9fa1265d7caee03e62852ccd5fa15', '[\"*\"]', NULL, '2024-03-09 07:41:27', '2024-03-09 07:41:27'),
(26, 'App\\Models\\User', 1, 'عبد الرازق', '306743db3bf3d54a47b964372e88a038671aa6ae199d9f28553ba0c1a5690bb0', '[\"*\"]', NULL, '2024-03-09 07:41:27', '2024-03-09 07:41:27'),
(27, 'App\\Models\\User', 1, 'عبد الرازق', '3b8ef735fed0daf85797008c076eb5bec278a1f21540da6dca8bb086dfe61d11', '[\"*\"]', NULL, '2024-03-09 07:42:02', '2024-03-09 07:42:02'),
(28, 'App\\Models\\User', 1, 'عبد الرازق', 'd95e53edbd0cda22cde22cdf44a97e5d0ddf45daa20c6e4a275feabf3301337e', '[\"*\"]', NULL, '2024-03-09 07:42:02', '2024-03-09 07:42:02'),
(29, 'App\\Models\\User', 1, 'عبد الرازق', '5e0a026f67cc5c71545b4b5491162398f4a80915752e22c0302a15d485c864cd', '[\"*\"]', NULL, '2024-03-09 07:43:47', '2024-03-09 07:43:47'),
(30, 'App\\Models\\User', 1, 'عبد الرازق', 'd42178f7d1d88b1400c602b6fda9b8d182d40b6fb5f1864fac19da64950fbf54', '[\"*\"]', NULL, '2024-03-09 07:43:47', '2024-03-09 07:43:47');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 /*`status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',*/
 'is_completed' tinyint(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `desc`, `time`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'test', 'just for testing api', '2024-03-24 00:31:00', '0', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  'imagepath' varchar(255) utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`,'imagepath') VALUES
(1, 'عبد الرازق', 'sintac.code2020@gmail.com', NULL, '$2y$10$4ZDFcMVz79pjxNncJr96VuRcaMYiXKN6zjvGAHGlozr1vTPBsTSVq', NULL, '2024-03-09 05:52:42', '2024-03-09 05:52:42',NULL),
(2, 'عبد الرازق', 'ahmed9999re@gmail.com', NULL, '$2y$10$1PFysDFd9YJtqp/zzmMoMuTXXLwSfl3QOzQxhTwh14rb2LZale3Ne', NULL, '2024-03-09 05:58:45', '2024-03-09 05:58:45',NULL),
(3, 'أصول ثابتة', 'test@test.test', NULL, '$2y$10$DnlTmVCsigJaV6qI9HvIOOu4fsRAovyHxVzbxOERPbi05Dwobcf8y', NULL, '2024-03-09 06:07:23', '2024-03-09 06:07:23',NULL),
(4, 'مبنى العاصة الإدارية', 'abdo@sintac.site', NULL, '$2y$10$XvGVDOVst8uj1LlgKce5XuASliLFuwAGi6dNfEAo2pCtgurZMgv9y', NULL, '2024-03-09 06:11:06', '2024-03-09 06:11:06',NULL),
(5, 'مبنى العاصة الإدارية', 'abdo@sintaco.site', NULL, '$2y$10$xc4p65k61COqVU4lx1EdtO1Y142tyWpSqCg5FToXFHKfdITnqE25i', NULL, '2024-03-09 06:13:33', '2024-03-09 06:13:33',NULL),
(6, 'test', 'test@testl.test', NULL, '$2y$10$7oJcmOil8yNGQPdvlrxmw..LRs9Nj8HlwRc/L1GxzskaWvxFFqKEi', NULL, '2024-03-09 06:22:37', '2024-03-09 06:22:37',NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
