<?php

namespace App\Http\Controllers;

use App\Models\tasks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TasksController extends Controller
{  /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   /* public function index(Request $request)
{
    $user_id = $request->input('user_id');
    $tasks = Tasks::where('user_id', $user_id)->get();

    return response()->json(['tasks' => $tasks]);
}*/
   /* /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */ 
    public function index (Request $request)
    {

        $tasks = Tasks::where('user_id', $request->user_id)->get();

        return response()->json(['tasks' => $tasks]);
    }
   
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(): void
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'desc' => 'required',
           'timeing' => 'required',
            'user_id' => 'required',
            'is_completed' => 'required',

        ]);
        $task = tasks::create([
            'name' => $request->name,
            'desc' => $request->desc,
            'timeing' =>$request->timeing,
            'user_id' => $request->user_id,
            'is_completed' => $request->is_completed,
        ]);

        return response()->json([
            'message' => 'تم حفظ المهمة بنجاح',
            'task' => $task,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\tasks  $tasks
     * @return \Illuminate\Http\Response
     */
    public function show(tasks $tasks, $taskId)
    {
        $task = Tasks::find($taskId);

        if (!$task) {
            return response()->json(['message' => 'المهمة غير موجودة'], 404);
        }

        return response()->json(['task' => $task]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\tasks  $tasks
     * @return \Illuminate\Http\Response
     */
    public function edit(tasks $tasks)
    {
        $task = tasks::find($tasks);
        
        if (!$task) {
            return response()->json(['message' => 'Task not found'], 404);
        }
        
        // Add your edit logic here
        
        return response()->json(['task' => $task]);
    }
    /*public function edit(tasks $tasks)
    {
        //
    }*/

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\tasks  $tasks
     * @return \Illuminate\Http\Response
     */
    public function toggleStatus(Request $request, $taskId)
    {
        $task = Tasks::find($taskId);

        if (!$task) {
            return response()->json(['message' => 'المهمة غير موجودة'], 404);
        }
        $task->is_completed = $task->is_completed  == 0 ? 1 : 0;
       //$task->status = $task->status == 0 ? 1 : 0;
        $task->save();

        return response()->json(['message' => 'تم تحديث الحالة بنجاح', 'task' => $task]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\tasks  $tasks
     * @return \Illuminate\Http\Response
     */
    public function destroy(tasks $tasks, $taskId)
    {
        $task = Tasks::find($taskId);

        if (!$task) {
            return response()->json(['message' => 'المهمة غير موجودة'], 404);
        }

        $task->delete();

        return response()->json(['message' => 'تم حذف المهمة بنجاح']);
    }
       /**
     * Display the tasks that have been completed.
     *
     * @return \Illuminate\Http\Response
    */
    public function getCompletedTasks()
    {
    // Retrieve completed tasks
    $completedTasks = Tasks::where('status', 1)->get();

    // Check if there are any completed tasks
    if ($completedTasks->isEmpty()) {
        return response()->json(['message' => 'No completed tasks found.'], 200);
    }

    // Return the completed tasks
    return response()->json(['completed_tasks' => $completedTasks], 200);
    }
    /**
     * Update the description of the specified task.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $taskId
     * @return \Illuminate\Http\Response
     */
    public function updateDescription(Request $request, $taskId)
    {
    // ابحث عن المهمة المحددة
    $task = Tasks::find($taskId);

    // التحقق مما إذا كانت المهمة موجودة أو لا
    if (!$task) {
        return response()->json(['message' => 'المهمة غير موجودة'], 404);
    }

    // تحديث وصف المهمة
    $task->desc = $request->input('desc');
    $task->save();

    // إرجاع رسالة بنجاح التحديث
    return response()->json(['message' => 'تم تحديث وصف المهمة بنجاح', 'task' => $task]);
    }

}

