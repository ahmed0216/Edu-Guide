<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\tasks;

class AuthController extends Controller
{
      /*public function signUp(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'password' => 'required',
        ]);

        $max = User::max('id') + 1;
        $user = User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
        ]);

        $user = User::where('email', $request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            //return 'فشل في إنشاء الحساب';
          return response()->json([
                'message' => 'الحساب موجود بالفعل',
                'status' => false
            ], 409);
        }

        $user->createToken($user->name)->plainTextToken;
        $token = $user->createToken($user->name)->plainTextToken;
        return response()->json([
            'token' => $token,
            'user' => $user,
             ' imagePath' => $user,
            'status' => true,
            'massage' => 'تم تسجيل الحساب بنجاح'
        ]);
    }*/
 public function signUp(Request $request)
{
    $request->validate([
        'name' => 'required',
        'email' => 'required',
        'password' => 'required',
       // 'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
    ]);

    // التحقق مما إذا كان المستخدم موجود بالفعل
    $user = User::where('email', $request->email)->first();
    if ($user) {
        return response()->json([
            'message' => 'الحساب موجود بالفعل',
            'status' => false
        ], 409);
    }

    // حفظ الصورة واستخراج المسار
  /*  $imagePath = null;
    if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('images');
    }*/

    // إنشاء المستخدم مع تخزين مسار الصورة
    $user = User::create([
        'name' => $request['name'],
        'email' => $request['email'],
        'password' => Hash::make($request['password']),

       // 'image_path' => $imagePath, // استخدم اسم الحقل الصحيح هنا
    ]);

    // إنشاء الرمز المميز وحفظه في متغير
    $token = $user->createToken($user->name)->plainTextToken;

    return response()->json([
        'token' => $token,
        'user' => $user,
        'status' => true,
        'massage' => 'تم تسجيل الحساب بنجاح'
    ]);
}



    public function logIn(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
       
            return response()->json([
                'message' => 'خطأ في الايميل او كلمة المرور',
                'status' => false
            ], 401); // Use appropriate HTTP status code for unauthorized access
           // return '   خطأ في الايميل او كلمة المرور';
        }

        $user->createToken($user->name)->plainTextToken;
        $token = $user->createToken($user->name)->plainTextToken;
        $tasks = Tasks::where('user_id', $user->id)->get();

        return response()->json([
            'token' => $token,
            'user' => $user,
            'tasks' => $tasks,
            'status' => true,
            'massage' => 'تم تسجيل الدخول بنجاح'
        ]);
    }
    
    public function logOut(Request $request)
    {
        DB::table("personal_access_tokens")->where('tokenable_id', $request->tokenable_id)->delete();
        return 'success';
    }
   /* public function delete(Request $request)
    {
        $user = User::where('id', $request->tokenable_id)->first();
        DB::table("personal_access_tokens")->where('tokenable_id', $request->tokenable_id)->delete();
        $user::delete();
        return 'تم حذف الحساب بنجاح';
    }*/
    public function deleteUser(Request $request)
   {
    $user = User::find($request->tokenable_id);

    if (!$user) {
       // return 'لم يتم العثور على المستخدم';
       return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
    }

    // حذف جميع الرموز المصنفة للمستخدم
    DB::table("personal_access_tokens")->where('tokenable_id', $request->tokenable_id)->delete();

    // حذف المستخدم
    $user->delete();

    return 'تم حذف الحساب بنجاح';
   }
   public function updateImage(Request $request, $id)
{
    $request->validate([
        'image' => 'required|image',//|mimes:jpeg,png,jpg,gif|max:2048',
    ]);

    // البحث عن المستخدم بناءً على معرفه
    $user = User::find($id);

    // التأكد من أن المستخدم موجود
    if (!$user) {
        return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
    }

    // التحقق من وجود صورة محدثة
    if ($request->hasFile('image')) {
        $image = $request->file('image');
        $extension= $image->getClientOriginalExtension();
        $imageName = time() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('images'), $imageName);
       // $user->image_path ='images/'.$imageName;
       // حفظ مسار الصورة في جدول المستخدم
        $user->image_path =/* 'images/' .*/ $imageName;}
        $user->save();
        $user->image_path = asset('images/'.$imageName);

    return response()->json([
        'message' => 'تم تحديث صورة المستخدم بنجاح',
        'user' => $user
    ]);
}
   public function updateUser(Request $request, $id)
   {
       $request->validate([
           'email' => 'required|email',
           'name' => 'required',
       ]);
   
       // البحث عن المستخدم بناءً على معرفه
       $user = User::find($id);
   
       // التأكد من أن المستخدم موجود
       if (!$user) {
           return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
       }
   
       // تحديث بيانات المستخدم
       $user->email = $request->email;
       $user->name = $request->name;
       $user->save();
   
       return response()->json([
           'message' => 'تم تحديث بيانات المستخدم بنجاح',
           'user' => $user
       ]);
   }
   
  /* public function updateUser(Request $request, $id)
   {
       $request->validate([
           'email' => 'required|email',
           'name' => 'required',
       ]);
   
       // البحث عن المستخدم بناءً على معرفه
       $user = User::find($id);
   
       // التأكد من أن المستخدم موجود
       if (!$user) {
           return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
       }
   
       // تحديث بيانات المستخدم
       $user->email = $request->email;
       $user->name = $request->name;
       $user->save();
   
       return response()->json([
           'message' => 'تم تحديث بيانات المستخدم بنجاح',
           'user' => $user
       ]);
   }*/

   
  /* public function updateUser(Request $request, $id)
   {
       $request->validate([
           'email' => 'required|email',
           'name' => 'required',
           'image_path' => 'nullable', // إزالة القاعدة التي تحدد نوع الصورة
       ]);
   
       $user = User::find($id);
   
       if (!$user) {
           return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
       }
   
       $user->email = $request->email;
       $user->name = $request->name;
       $user->image_path = $request->image_path; // يمكنك تخزين أي قيمة هنا
       $user->save();
   
       return response()->json([
           'message' => 'تم تحديث بيانات المستخدم بنجاح',
           'user' => $user
       ]);
   }*/
   



/*public function updateUser(Request $request, $id)
{
    $request->validate([
        'email' => 'required|email',
        'name' => 'required',
    ]);

    // البحث عن المستخدم بناءً على معرفه
    $user = User::find($id);

    // التأكد من أن المستخدم موجود
    if (!$user) {
        return response()->json(['error' => 'لم يتم العثور على المستخدم'], 404);
    }

    // تحديث بيانات المستخدم
    $user->email = $request->email;
    $user->name = $request->name;
    $user->save();

    return response()->json([
        'message' => 'تم تحديث بيانات المستخدم بنجاح',
        'user' => $user
    ]);
}

    public function userUpdate(Request $request)
    {
        $user = User::where('id', $request->tokenable_id)->first();
        if (Hash::check($request->old_password, $user->password)) {
            $user::update([
                'password' => Hash::make($request['password'])
            ]);    
            return ' تم تحديث كلمة المرور';
        }
    }*/


}